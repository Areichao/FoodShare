import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF6F35A5);
const kprimaryLightColor = Color(0xFFF1E6FF);
