Run a build to see the packages list.

FlutLab runs the "pub get" command automatically when you start any build or hot reload.
The full list of packages of the current project will be shown in this auto-generated file (packages.md).

You will find all information in the outputs in case of errors or version conflicts.